"""
Version information for BranchMapper application.
"""

__version__ = "0.9.0"

