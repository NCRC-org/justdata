"""
Shared utility functions for all applications.
"""

