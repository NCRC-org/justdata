"""
Shared web application components.
"""

