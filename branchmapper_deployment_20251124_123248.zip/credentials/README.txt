Place your bigquery_service_account.json file here.

Alternatively, set the GOOGLE_APPLICATION_CREDENTIALS environment variable
to point to your credentials file location.