"""
BranchSeeker Application

Banking market intelligence and branch network analysis module.
This is the core banking analysis functionality migrated from the existing codebase.
"""

__version__ = "1.0.0"
__description__ = "Banking market intelligence and branch network analysis"

