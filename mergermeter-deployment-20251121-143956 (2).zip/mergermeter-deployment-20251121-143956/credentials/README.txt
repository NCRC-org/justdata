Place your GCP credentials JSON file here.
Then update .env file with: GOOGLE_APPLICATION_CREDENTIALS=./credentials/your-file.json
