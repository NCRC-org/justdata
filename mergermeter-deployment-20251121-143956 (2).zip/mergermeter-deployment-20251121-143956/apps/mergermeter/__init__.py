"""
MergerMeter - Two-bank merger impact analyzer
"""

__version__ = "1.0.0"

