"""
Shared reporting utilities for all applications.
"""

