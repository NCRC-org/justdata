"""
Shared AI analysis utilities for all applications.
"""

