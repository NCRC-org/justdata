#!/bin/bash
cd "$(dirname "$0")"
echo "Starting DataExplorer..."
echo "Access at: http://localhost:8085"
python3 run_dataexplorer.py
