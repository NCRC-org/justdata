"""
DataExplorer - Interactive Dashboard for HMDA, Small Business, and Branch Data
"""

__version__ = "1.0.0"

